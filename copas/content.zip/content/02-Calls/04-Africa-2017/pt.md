---
title: Convite à apresentação de propostas - África sub-Sahariana, 2017
---
# Convite à apresentação de propostas - África sub-Sahariana, 2017

GBIF espera emitir um convite à apresentação de propostas para o [países ACP nas ilhas do Pacífico](https://ec.europa.eu/europeaid/regions/african-caribbean-and-pacific-acp-region_en) de 2017. 

Inscreva-se no [lista de e-mail BID](http://#)para receber atualizações em tempo real.

>*Este programa é financiado pela [União Europeia](http://www.europa.eu)*
>![Flag of the European Union](/images/flag-yellow-low.jpg)