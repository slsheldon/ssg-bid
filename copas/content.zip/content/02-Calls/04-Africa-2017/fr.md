---
title: Appel à propositions – Afrique subsaharienne, 2017
---
# Appel à propositions – Afrique subsaharienne, 2017

GBIF prévoit émettre un deuxième appel à propositions pour [ACP countries from sub-Saharan Africa](https://ec.europa.eu/europeaid/regions/african-caribbean-and-pacific-acp-region_en) in 2017.

Sign up for the [BID mailing list](http://#) to receive timely updates.

GBIF prévoit publier un appel à propositions pour les [pays ACP de l'Afrique subsaharienne](https://ec.europa.eu/europeaid/regions/african-caribbean-and-pacific-acp-region_en) dans 2017.

Inscrivez-vous à la [liste de diffusion BID](http://#) pour recevoir des mises à jour en temps opportun.

>*Ce programme est financé par [l'Union européenne](http://www.europa.eu)*
>![Flag of the European Union](/images/flag-yellow-low.jpg)