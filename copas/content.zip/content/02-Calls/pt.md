---
title: Convite à apresentação de propostas
---
# Convite à apresentação de propostas 

**NOTA: Atualmente não há convites abertos à apresentação**

O prazo para a apresentação de notas iniciais conceito de África sub-Sahariana foi de 20 novembro de 2015. GBIF e do painel de avaliação da proposta forneceram feedback e recomendações aos candidatos convidados a preparar propostas completas. Essas propostas são devidos xx fevereiro 2016, e GBIF vai anunciar os projectos seleccionados em Março / Abril de 2016.

Se você foi convidado a apresentar uma proposta completa, encontrar a informação completa sobre os tipos de subvenção aqui:
+ [Subvenções regionais](/africa-2015/subvenções-regionais)
+ [Subvenções nacionais](/africa-2015/subvenções-nacionais)
+ [Pequenas bolsas](/africa-2015/pequenas-bolsas)

GBIF emitirá convites à apresentação de [países ACP](https://ec.europa.eu/europeaid/regions/african-caribbean-and-pacific-acp-region_en) nas Caraíbas e do Pacífico Ilhas durante Q2 de 2016, com uma segunda e última chamada para os países ACP África sub-Sahariana planejado em 2017.

Inscreva-se no [mailing list BID](http://#) para receber atualizações em tempo real.

------

>*Este programa é financiado pela [União Europeia](http://www.europa.eu)*
>![Flag of the European Union](/images/flag-yellow-low.jpg)