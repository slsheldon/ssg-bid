---
title: FAQ
---

# Perguntas frequentes

Esta página está disponível apenas em Inglês. Você pode consultar a lista de perguntas frequentes sobre chamadas de propostas em 2015 [aqui](en.md).

>*Este programa é financiado pela [União Europeia](http://www.europa.eu)*
>![Flag of the European Union](/images/flag-yellow-low.jpg)