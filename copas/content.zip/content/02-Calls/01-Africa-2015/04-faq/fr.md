---
title: FAQ
---

# Foire aux questions

Cette page est seulement disponible en anglais. Vous pouvez consulter la liste de la FAQs sur les appels à propositions 2015 [ici](en.md).

>*Ce programme est financé par [l'Union européenne](http://www.europa.eu)*
>![Flag of the European Union](/images/flag-yellow-low.jpg)