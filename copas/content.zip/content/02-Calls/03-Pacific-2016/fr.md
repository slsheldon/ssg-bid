---
title: Appel à propositions – Pacifique, 2016
---
# Appel à propositions – Pacifique, 2016

GBIF prévoit publier un appel à propositions pour les [pays ACP dans les îles du Pacifique](https://ec.europa.eu/europeaid/regions/african-caribbean-and-pacific-acp-region_en) dans le deuxième trimestre de 2016. Regardez pour plus d'informations au début 2016.

Inscrivez-vous à la [liste de diffusion BID](http://#) pour recevoir des mises à jour en temps opportun.

>*Ce programme est financé par [l'Union européenne](http://www.europa.eu)*
>![Flag of the European Union](/images/flag-yellow-low.jpg)