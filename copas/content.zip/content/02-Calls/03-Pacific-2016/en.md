---
title: Call for proposals – Pacific, 2016
---
# Call for proposals – Pacific, 2016

GBIF expects to issue a call for proposals for the [ACP countries in the Pacific Islands](https://ec.europa.eu/europeaid/regions/african-caribbean-and-pacific-acp-region_en) in the second quarter of 2016. Look for more information in early 2016.

Sign up for the [BID mailing list](http://#) to receive timely updates.

>*This programme is funded by the [European Union](http://www.europa.eu)*
>![Flag of the European Union](/images/flag-yellow-low.jpg)